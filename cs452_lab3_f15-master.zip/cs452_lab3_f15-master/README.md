Fall 2015 CS 452 Lab 3 Process Scheduling

Authors: Adam Tjaden (tjadenad@uwec.edu) Lucas Zutter (zutterlp@uwec.edu)

To make:

make clean
make

To run:

./main [filename]

where [filename] is the name of the file with processes to load.

Note: The file is assumed to have the first line with column headers and a newline at the end.